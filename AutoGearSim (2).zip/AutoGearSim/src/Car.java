public class Car extends Vehicle {
    private final int Gear1 = 1;

    private final int Gear2 = 2;
    private final int Gear3 = 3;
    private final int Gear4 = 4;
    private final int Gear5 = 5;

    private final int Break1 = 1;
    private final int Break2 = 2;
    private final int Break3 = 3;
    private final int Break4 = 4;
    private final int Break5 = 5;

    private final int Highest_Speed_Gear1 = 10;
    private final int Highest_Speed_Gear2 = 20;
    private final int Highest_Speed_Gear3 = 30;
    private final int Highest_Speed_Gear4 = 40;

    private final int Highest_Speed_Break1 = 40;
    private final int Highest_Speed_Break2 = 30;
    private final int Highest_Speed_Break3 = 20;
    private final int Highest_Speed_Break4 = 10;


    public int returnGear(int speed) {
        if (speed <= Highest_Speed_Gear1)
            setGearValue(Gear1);
        else if (speed > Highest_Speed_Gear1 && speed <= Highest_Speed_Gear2)
            setGearValue(Gear2);
        else if (speed > Highest_Speed_Gear2 && speed <= Highest_Speed_Gear3)
            setGearValue(Gear3);
        else if (speed > Highest_Speed_Gear3 && speed <= Highest_Speed_Gear4)
            setGearValue(Gear4);
        else if (speed > Highest_Speed_Gear4)
            setGearValue(Gear5);
        else
            System.out.println("Wroom Wroom!");
        return getGearValue();
    }

    public int returnBreak(int speed) {
        if (speed <= Highest_Speed_Break1)
            setGearValue(Break1);
        else if (speed > Highest_Speed_Break2 && speed <= Highest_Speed_Break2)
            setGearValue(Gear2);
        else if (speed > Highest_Speed_Break3 && speed <= Highest_Speed_Break3)
            setGearValue(Break3);
        else if (speed > Highest_Speed_Break4 && speed <= Highest_Speed_Break4)
            setGearValue(Break4);

        else
            System.out.println("Wroom Wroom!");
        return getBreakValue();
    }
}