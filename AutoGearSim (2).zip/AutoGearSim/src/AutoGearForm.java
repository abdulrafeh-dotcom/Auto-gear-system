import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class AutoGearForm extends JFrame{
    private JPanel panelMain;
    private JTextField txtSpeed;
    private JButton showSpeed;
    private JSlider sliderAccelerate;
    private JProgressBar pbSpeed;
    private JLabel labelGearValue;
    private JLabel txtGearValue;
    private JLabel txtspeedValue;
    private JSlider Break;

    public AutoGearForm() {
        sliderAccelerate.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                    Car myAuto = new Car();
                    int acc = sliderAccelerate.getValue();
                    pbSpeed.setValue(acc * 10);
                    txtspeedValue.setText(pbSpeed.getValue() + " km/h");
                    txtGearValue.setText(String.valueOf(myAuto.returnGear(pbSpeed.getValue())));
                }
        });
        Break.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                Car myAuto = new Car();
                int acc = Break.getValue();
                pbSpeed.setValue(pbSpeed.getValue()-10);
                txtspeedValue.setText(pbSpeed.getValue() + " km/h");
                txtGearValue.setText(String.valueOf(myAuto.returnGear(pbSpeed.getValue())));

            }
        });
    }
    public static void main (String[] args)
    {
        AutoGearForm agrSim = new AutoGearForm();
        agrSim.setContentPane(agrSim.panelMain);
        agrSim.setTitle("Auto Gear Simulation");
        agrSim.setSize(400,400);
        agrSim.setVisible(true);
        agrSim.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);



    }
}
