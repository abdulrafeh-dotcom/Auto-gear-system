import javax.swing.*;

public class Vehicle {
    private int gear;
    private int breaks;

    public int getGearValue()
    {
        return gear;
    }
    public void setGearValue(int gear)
    {
        this.gear = gear;
    }

    public int getBreakValue()
    {
        return breaks;
    }
    public void setBreakValue(int breaks)
    {
        this.breaks = breaks;
    }

}
